$(document).ready(function() {
  var btn = document.getElementById("read");
  btn.addEventListener("click", function() {
    
 
  
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("read");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = '<i class="fas fa-angle-right">' + "Read more" ;  
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML ='<i class="fas fa-angle-up">' +   "Read less"; 
      moreText.style.display = "inline";
    }
  
   }, false); 

});
var slider = tns({
    "container": ".my-slider",
    "items": 4,
    "gutter": 10,
    "loop": true,
    "nav": false,
    "controlsPosition": top,
    "swipeAngle": false,
    "autoWidth": true,
    "speed": 400,
    controlsContainer: "#customize-controls",
    responsive: {
        200: {
            items: 1,
        },
        
        800: {
            items: 3,
        }
    }
  });
