<section class="footer-one">
            <div class="container flex-container">
                <div class="col1">
                    <h2><b>About us</b>
                    </h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                     Maecenas ut nulla sapien, at aliquam erat. Sed vitae massa tellus. 
                     Aliquam commodo aliquam metus, sed iaculis nibh tempus id. Lorem ipsum dolor sit amet, 
                     consectetur adipiscing elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrice.</p>
                </div>
                <div class="col2">
                    <h2><b>
                     Explore</b>
                    </h2>
                        <p><a href="/">Home</a></p>
                        <p><a href="/">About us</a></p>
                        <p><a href="/">Services</a></p>
                        <p><a href="/">Portfolio</a></p>
                        <p><a href="/">Blog</a></p>
                </div>
                <div class="col3">
                 <h2><b>
                 Browse</b>
                 </h2>
                 
                     <p><a href="/">Careers</a></p>
                     <p><a href="/">Press & Media</a></p>
                     <p><a href="C:\MAMP\htdocs\php\projektas\app\views\form.php">Contact Us</a></p>
                     <p><a href="/">Terms of Service</a></p>
                     <p><a href="/">Privacy Policy</a></p>
                 
             </div>
             <div class="col4">
                 <h2><b>Contact us</b></h2>
                 <div class="pastraipa">
                 <p><b>BisLite Inc.</b></p>
                 <p>Always Street 265</p>
                 <p>0X-125-Canada</p>
             </div>
             <div class="pastraipa">
                 <p><a href="tel:9876543210">Phone: 987-6543-210</a></p>
                 <p>Fax: 987-6543-210</p>
             </div>
             </div>
             <div class="col5">
                 <h2><b>Connect with us</b></h2>
                 <div class="ikonos flex-container">
                 <a href="https://www.pinterest.com/" target="_blank"><i class="fab fa-pinterest"></i></a>
                 <a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook"></i></a>
                 <a href="https://www.skype.com/en/" target="_blank"><i class="fab fa-skype"></i></a>
                 <a href="https://www.google.com/" target="_blank"><i class="fab fa-google-plus"></i></a>
                 <a href="https://www.whatsapp.com/" target="_blank"><i class="fab fa-whatsapp"></i></a>
                 <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
             </div>
             </div>
            </div>
        </section>
        <section class="footer-two">
            <div class="container flex-container">
                <div class="futeris">
             <p>&copy; Copyright 2012 - BisLite Inc. All rights reserved. Some free icons used here are created by Brankic1979.com.</p>
             <p>Client Logos are copyright and trademark of the respective owners / companies</p>
            </div>
             <img src="../app/images/logo.png" alt="logo">
         </div>
     
        </section>