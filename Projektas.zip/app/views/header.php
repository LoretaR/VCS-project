<header class="site-header">
        <div class="container flex-container">
            <div class="logo">
                <a href="index.php"><img src="../app/images/logo.png" alt="logo"></a>
            </div>
            <nav class="main-nav">
                <ul class="flex-container">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">About us</a></li>
                    <li class="dropdown">
                       <a href="javascript:void(0)" class="dropbtn"> Services <i class="fas fa-caret-down"></i></a>
                        <div class="dropdown-content">
                                <a href="www.facebook.com">Web Design</a>
                                <a href="#">Wordpress Design</a>
                                <a href="#">Mobile App Devplopment</a>
                                <a href="#">Internet Marketing</a>
                                <a href="#">Social Media Management</a>
                            </div>
                            </li>
                            <li class="dropdown">
                                <a href="javascript:void(0)" class="dropbtn"> Portfolio <i class="fas fa-caret-down"></i></a>
                                 <div class="dropdown-content">
                                         <a href="www.google.com">Web Design</a>
                                         <a href="#">Wordpress Design</a>
                                         <a href="#">Mobile App Devplopment</a>
                                         <a href="#">Internet Marketing</a>
                                         <a href="#">Social Media Management</a>
                                     </div>
                                     </li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="form.php">Contact us</a></li>
                </ul>
            </nav>
            <nav class="mobile-nav">
                <ul id="mMenu" class="flex-container"> 
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About</a></li>
                    <li class="dropdown">
                                <a href="javascript:void(0)" class="dropbtn"> Portfolio <i class="fas fa-caret-down"></i></a>
                                 <div class="dropdown-content">
                                         <a href="www.google.com">Web Design</a>
                                         <a href="#">Wordpress Design</a>
                                         <a href="#">Mobile App Devplopment</a>
                                         <a href="#">Internet Marketing</a>
                                         <a href="#">Social Media Management</a>
                                     </div>
                                     </li>
                            
                    <li><a href="#">Blog</a></li>
                    <li><a href="/public/form.php">Contact us</a></li>
                </ul>
                <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                    <i class="fa fa-bars"></i>
                </a>
            </nav>
        </div>
    </header>