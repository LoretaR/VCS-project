<?php
if(isset($_POST['submit'])) {
$name = trim($_POST['name']);
$email = trim($_POST['email']);
$subject = trim($_POST['subject']);
$descrip = trim($_POST['descrip']);

if(!empty($name) && !empty($email) && !empty($subject) && !empty($descrip)) {

    if(filter_var($email, FILTER_VALIDATE_EMAIL)){
        $from = "$email";
        $to = "Raudyte.Loreta@gmail.com";
        $subject = "nauja zinute";
        $autorius = 'Nuo: ' . $name . ', ' . $email;
        $zinute = htmlspecialchars($descrip);
        mail($to, $subject, $autorius, $zinute, $from);
        echo "<script>alert('Dekojame. Jusu zinute gauta. Netrukus susisieksime.');</script>";
    }
}
include 'C:\MAMP\htdocs\php\app\src\db.php';
}

