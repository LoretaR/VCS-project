<?php
    define("DB_SERVER", "localhost:3307");
    define("DB_USER", "root");
    define("DB_PASSWORD", "root");
    define("DB_NAME", "forma");

    $mysqli = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
    if($mysqli->connect_error) {
        echo 'Atsiprasome, bet svetaine susidure su problema.\n';
        echo 'Klaida: ' . $mysqli->connect_error . '\n';
        exit();
    }

    mysqli_query($mysqli, "INSERT INTO klientai (name, email, subject, descrip) 
    VALUES('$_POST[name]', '$_POST[email]', '$_POST[subject]', '$_POST[descrip]')");