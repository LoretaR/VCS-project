<?php
require ('C:\MAMP\htdocs\php\app\src\app.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projektas</title>
    <script src="https://kit.fontawesome.com/b7d1db21b6.js" crossorigin="anonymous"></script>
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.3/tiny-slider.css">
    <link rel="stylesheet" href="/../php/app/css/style.css">
</head>

    <body>
       
   <?php include('../app/views/header.php')?>
    <section class="kontaktine-forma">
        <div class="container">
        <div class="pavadinimas-forma">
            <h2><i class="fas fa-envelope"></i>Contact Us</h2></div>
        <div class="grid-container1">
        <p>Thank you for stoping by. Please use the form below to contact us and will get back to you at the earliest possible</p>
        <p>For feedback or questions, please email us at: <a href="mailto:webmaster@example.com">email@bislite.com</a></p>
        <form id="contact" action="/../php/public/form.php" method="post">
            <label for="name">Name</label><br>
            <input type="text" id="name" name="name"><br>
            <label for="email">Email Address</label> <br>
            <input type="text" id="email" name="email"><br>
            <label for="subject">Subject</label><br>
            <input type="text" id="subject" name="subject"><br>
            <label for="descrip">Description</label><br>
            <textarea id="descrip" name="descrip"></textarea> <br>
            <button name="submit" type="submit" id="contact-submit"><i class="fas fa-arrow-alt-circle-right" aria-hidden="true"></i><b>Submit</b></button>
        </form>
<div class="map">
    <h3>We are here</h3>
        <img src="../app/images/map.png" alt="zemelapis">
        <h2>Offise addresess</h2>
                 <div class="pastraipa">
                 <p><b>BisLite Inc.</b></p>
                 <p>Always Street 265</p>
                 <p>0X-125-Canada</p>
             </div>
             <div class="pastraipa">
                 <p><a href="tel:9876543210">Phone: 987-6543-210</a></p>
                 <p>Fax: 987-6543-210</p>
             </div>
</div>
        </div>
    </div>
    </section>

    <?php include('C:\MAMP\htdocs\php\app\views\footer.php')?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.2/min/tiny-slider.js"></script>
    <script src="custom.js"></script>         
</body>
</html>