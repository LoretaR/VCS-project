
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projektas</title>
    <script src="https://kit.fontawesome.com/b7d1db21b6.js" crossorigin="anonymous"></script>
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.3/tiny-slider.css">
    <link rel="stylesheet" href="../app/css/style.css">
    <script>
        function myFunction() {
            var x = document.getElementById("mMenu");
            if (x.style.display === "block") {
                x.style.display = "none";
            } else {
                x.style.display = "block";
            }
        }
    </script>
</head>
<body>
<?php include('../app/views/header.php'); ?>

   <section class="pirmadalis">
       <div class="container flex-container">
           <div class="slider">

            <input type="radio" class="radio" name="images" id="radio-1">
            <input type="radio" class="radio" name="images" id="radio-2">
            <input type="radio" class="radio" name="images" id="radio-3" checked>
            <input type="radio" class="radio" name="images" id="radio-4">
            <input type="radio" class="radio" name="images" id="radio-5">

           <div class="slide" id="slide-1">
            <img src="../app/images/homepage.png" alt="Homepage" class="center">
        </div>
        <div class="slide" id="slide-2">
            <img src="../app/images/Full-skyline_simplified@1920px.png" alt="Homepage" class="center">
        </div>
        <div class="slide" id="slide-3">
            <img src="../app/images/homepage.png" alt="Homepage" class="center">
        </div>
        <div class="slide" id="slide-4">
            <img src="../app/images/Full-skyline_simplified@1920px.png" alt="Homepage" class="center">
        </div>
        <div class="slide" id="slide-5">
            <img src="../app/images/homepage.png" alt="Homepage" class="center">
        </div>
        <div class="dots">
            <label for="radio-1" id="label-1"></label>
            <label for="radio-2" id="label-2"></label>
            <label for="radio-3" id="label-3"></label>
            <label for="radio-4" id="label-4"></label>
            <label for="radio-5" id="label-5"></label>
        </div>
        </div>
    </div>
      </section>
          
    <section class="antradalis">
        <div class="container flex-container">

                <div class="p"><h2><i class="fas fa-pencil-alt"></i>Clean theme</h2>
               <p> Ut nec lorem id orci convallis porta. Donec pharetra neque velit dictum molestie. Duis porta gravida augue sed viverra. Quisque at nulla leo, non aliquet mi. Ut nec lorem id orci convallis porta. Donec pharetra neque velit dictum molestie. Duis porta gravida augue sed viverra. Quisque at nulla leo, non aliquet mi.
               
            <span id="dots">...</span>
               <span id="more">Ut nec lorem id orci convallis porta. Donec pharetra neque velit dictum molestie. Duis porta gravida augue sed viverra. Quisque at nulla leo, non aliquet mi.
                Ut nec lorem id orci convallis porta. Donec pharetra neque velit dictum molestie. Duis porta gravida augue sed viverra. Quisque at nulla leo, non aliquet mi.
                </span></p>
            

                <button id="read"> <i class="fas fa-angle-right"></i> Read more</button>
                
            </div>


                <div class="p"><h2><i class="fas fa-expand"></i>Responsive Design</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi euismod placerat dui et tincidunt. Sed sollicitudin posuere auctor. Phasellus at ultricies nisl. Integer al leo eros.</p>
                <a href="#"><i class="fas fa-angle-right"></i>Read more</a>   
            </div>
                <div class="p"><h2><i class="fas fa-bars"></i>Fully Layerd PSD</h2>
                <p>Phasellus lobortis metus non augue sodales volutpat. Vestibulum sit amet nibh eros, hendrerit venenatis est. In vitae nulla nec purus cursus pretium sed id magna.</p>
                <a href="#"><i class="fas fa-angle-right"></i>Read more</a>    
            </div>
                <div class="p"><h2><i class="fas fa-paper-plane"></i>Ready for coding</h2>
                <p>Vivamus convallis feugiat mauris sed posuere. Nam rutrum, quam quis euismod commodo, elit est porta quam, non placerat eros neque porta ante. Fusce qui sodio urna.</p>
                <a href="#"><i class="fas fa-angle-right"></i>Read more</a>
            </div>
            </div>
            </section>

            <section class="treciadalis">
                <div class="container">
                    <div class="pavadinimas">
           <h2><i class="fas fa-mouse-pointer"></i>Latest work</h2>
         
            <ul class="controls" id="customize-controls">
                <li class="prev" data-controls="prev" >
                    <i class="fas fa-angle-left"></i>
                </li>
           
                <li class="next" data-controls="next">
                    <i class="fas fa-angle-right"></i>          
                </li>
            </ul>
        </div>
           <div class="my-slider">
            
              <div><img id="ph1" src="../app/images/kaledos.png" alt="Kalėdinė"></div> 
             
              <div><img src="../app/images/kamera.png" alt="Kamera"></div>
           
              <div><img src="../app/images/metulaikai.png" alt="Metų laikai"></div>
          
                <div><img src="../app/images/notepad.png" alt="Užrašinė"></div>
              
                <div><img src="../app/images/piestukas.png" alt="Pieštukas"></div>

                <div><img src="../app/images/pilkas.png" alt="Pilka nuotrauka"></div>

                <div><img src="../app/images/sale.png" alt="Išpardavimas"></div>

                <div><img src="../app/images/smile.png" alt="Šypsena"></div>
             
          </div>
          </div>
          </section>
          <section class="ketvirtadalis">
            <div class="container grid-container">
                <div class="pavadinimas-atsiliepimai">
                    <h2><i class="far fa-comment-dots"></i>Testimonials</h2></div>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                        Maecenas ut nulla sapien, at aliquam erat. Sed vitae massa tellus. 
                        Aliquam commodo aliquam metus, sed iaculis nibh tempus id. Lorem ipsum dolor sit amet, 
                        consectetur adipiscing elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices 
                        posuere cubilia Curae; Etiam nec nisi in nisl euimod Fringilla.
                    <br>
                    <br>
                    <b><em>John Travis, CEO, DomainName.com</em></b></p>
        
                <div class="pavadinimas-klientai">
                    <h2><i class="fas fa-user-friends"></i>Our clients</h2></div>
                    <div class="clients">
                        <div class="flex-container">
                        
                        <img src="../app/images/lg1.png" alt="CoxCumunication">
                        
                        <img src="../app/images/lg2.png" alt="CNN">
                      
                        <img src="../app/images/lg3.png" alt="ApartmenFinder">
                       
                        <img src="../app/images/lg4.png" alt="JohnDeere">
                      
                        <img src="../app/images/lg5.png" alt="BananaBoat">
                      
                        <img src="../app/images/lg6.png" alt="Fujifilm">
                       
                    </div>
                </div>
                 
          </div>
          </section>

          <section class="penktadalis">
            <div class="container flex-container">
                <p>This is a clean and moder, four column website PSD template. You can code it into a Wordpress website, 
                    HTML5 responsive website for your personal or client works. So ahead and download this wonderful PSD template!</p>
                    
                    <a href="../cuda-orig.png" download>
                        <span class="mygtukas">
                        <i class="fas fa-download"></i><b>Download PSD</b>
                        </span>
                    </a>
                    
          </div>
          </section>
         

          <?php include('C:\MAMP\htdocs\php\app\views\footer.php')?>
    
        <script src="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.2/min/tiny-slider.js"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
        <script src="../js/custom.js"></script>         
</body>
</html>